﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1
{
    internal class Piłkarz
    {
        // private string _imie;

        #region Wlasnosci
        /*public string Imie { 
            get
            {
                return _imie;
            }
            set
            {
                _imie = value;
            }
        }*/
        public string Imie { get; set; }// = ""; //równoważne z tym wyżej
        public string Nazwisko { get; set; }
        public uint Wiek { get; set; }
        public uint Waga { get; set; }
        #endregion

        #region konstruktory
        public Piłkarz(string imie, string nazwisko, uint wiek, uint waga)
        {
            Imie = imie;
            Nazwisko = nazwisko;
            Wiek = wiek;
            Waga = waga;
        }

        //konstruktor dwuargumentowy "woła" czteroargumentowy
        public Piłkarz(string imie, string nazwisko) : this(imie, nazwisko, 25, 70) { }
        #endregion

        public override string ToString()
        {
            return $"{Imie} {Nazwisko} lat: {Wiek} waga: {Waga} kg";
        }

        public bool takiSam(Piłkarz pilkarz)
        {
            if (pilkarz.Nazwisko != Nazwisko)
                return false;
            if (pilkarz.Imie != Imie)
                return false;
            if (pilkarz.Wiek != Wiek)
                return false;
            if (pilkarz.Waga != Waga)
                return false;
            return true;
        }

        public string formatPlikowy()
        {
            return $"{Nazwisko} | {Imie} | {Wiek} | {Waga}";
        }

        public static Piłkarz CreateFromString(string zapisPilkarza)
        {
            string imie, nazwisko;
            uint wiek, waga;
            var pola = zapisPilkarza.Split(" | ");
            if (pola.Length == 4)
            {
                nazwisko = pola[0];
                imie = pola[1];
                wiek = uint.Parse(pola[2]);
                waga = uint.Parse(pola[3]);
                return new Piłkarz(imie, nazwisko, wiek, waga);
            }
            throw new Exception("Błędny format danych z pliku");
        }
    }
}
