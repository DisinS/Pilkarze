﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string plikArchiwizacji = "archiwum.txt";
        public MainWindow()
        {
            InitializeComponent();
            TextBoxWEPImie.setFocus();
        }

        private void buttonDodaj_Click(object sender, RoutedEventArgs e)
        {
            //operator logiczny & a nie podwójny operator warunkowy &&
            //sprawdź dlaczego
            //przy podwójnym operatorze warunek drugi nie będzie sprawdzony jeśli warunek pierwszy będzie false
            if (czyPusty(TextBoxWEPImie) & czyPusty(TextBoxWEPNazwisko))
            {
                var biezacyPilkarz = new Piłkarz(TextBoxWEPImie.tekst.Trim(), TextBoxWEPNazwisko.tekst.Trim(), (uint)WiekSlider.Value, (uint)WagaSlider.Value);
                var czyJuzJestNaLiscie = false;
                foreach (var p in listBoxPilkarze.Items)
                {
                    var pilkarz = p as Piłkarz;
                    if (pilkarz.takiSam(biezacyPilkarz))
                    {
                        czyJuzJestNaLiscie = true;
                        break;
                    }
                }
                if (!czyJuzJestNaLiscie)
                {
                    listBoxPilkarze.Items.Add(biezacyPilkarz);
                    czysc();
                }
                else
                {
                    var dialog = MessageBox.Show($"{biezacyPilkarz.ToString()} już jest na liście {Environment.NewLine} Czy wyczyścić formularz?", "Uwaga", MessageBoxButton.OKCancel);
                    if (dialog == MessageBoxResult.OK)
                    {
                        czysc();
                    }

                }
            }
        }

        private void buttonEdytuj_Click(object sender, RoutedEventArgs e)
        {
            if(czyPusty(TextBoxWEPImie) & czyPusty(TextBoxWEPNazwisko))
            {
                var biezacyPilkarz = new Piłkarz(TextBoxWEPImie.tekst.Trim(), TextBoxWEPNazwisko.tekst.Trim(), (uint)WiekSlider.Value, (uint)WagaSlider.Value);
                var czyJuzJestNaLiscie = false;
                foreach (var p in listBoxPilkarze.Items)
                {
                    var pilkarz = p as Piłkarz;
                    if (pilkarz.takiSam(biezacyPilkarz))
                    {
                        czyJuzJestNaLiscie = true;
                        break;
                    }
                }
                if (!czyJuzJestNaLiscie)
                {
                    var dialogResult = MessageBox.Show($"Czy na pewno chcesz zmienić dane  {Environment.NewLine} {listBoxPilkarze.SelectedItem}?", "Edycja", MessageBoxButton.YesNo);

                    if (dialogResult == MessageBoxResult.Yes)
                    {
                        listBoxPilkarze.Items[listBoxPilkarze.SelectedIndex] = new Piłkarz(biezacyPilkarz.Imie, biezacyPilkarz.Nazwisko, biezacyPilkarz.Wiek, biezacyPilkarz.Waga);
                    }
                    czysc();
                    listBoxPilkarze.SelectedIndex = -1;

                }
                else
                    MessageBox.Show($"{biezacyPilkarz.ToString()} już jest na liście.", "Uwaga");
            }
        }

        private void buttonUsun_Click(object sender, RoutedEventArgs e)
        {
            var biezacyPilkarz = new Piłkarz(TextBoxWEPImie.tekst.Trim(), TextBoxWEPNazwisko.tekst.Trim(), (uint)WiekSlider.Value, (uint)WagaSlider.Value);
            var czyJestNaLiscie = false;

            foreach (var p in listBoxPilkarze.Items)
            {
                var pilkarz = p as Piłkarz;
                if(biezacyPilkarz.takiSam(pilkarz))
                {
                    czyJestNaLiscie = true;
                    break;
                }
            }
            if (czyJestNaLiscie)
            {
                var dialogResult = MessageBox.Show($"Czy na pewno chcesz usunąć piłkarza  {Environment.NewLine} {listBoxPilkarze.SelectedItem}?", "Usuwanie", MessageBoxButton.YesNo);

                if (dialogResult == MessageBoxResult.Yes)
                {    
                    foreach (var p in listBoxPilkarze.Items)
                    {
                        var pilkarz = p as Piłkarz;
                        if (pilkarz.takiSam(biezacyPilkarz))
                        {
                            listBoxPilkarze.Items.RemoveAt(listBoxPilkarze.SelectedIndex);
                            break;
                        }
                    }
                }
                czysc();
                listBoxPilkarze.SelectedIndex = -1;
            }
            else
            {
                MessageBox.Show($"{biezacyPilkarz.ToString()} nie figuruje na liście.", "Uwaga");
            }
        }

        private void listBoxPilkarze_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (listBoxPilkarze.SelectedIndex > -1)
            {
                wczytajPilkarza((Piłkarz)listBoxPilkarze.SelectedItem);
            }
        }

        private bool czyPusty(TextBoxWithErrorProvider zawartoscPola)
        {
            if (zawartoscPola.tekst.Trim() == "")
            {
                zawartoscPola.blad("Pole nie może być puste!");
                return false;
            }
            else
            {
                zawartoscPola.blad("");
                return true;
            }
        }

        private void czysc()
        {
            TextBoxWEPImie.tekst = "";
            TextBoxWEPNazwisko.tekst = "";
            WiekSlider.Value = 20;
            WagaSlider.Value = 80;
            buttonEdytuj.IsEnabled = false;
            buttonUsun.IsEnabled = false;

            listBoxPilkarze.SelectedIndex = -1;
            TextBoxWEPImie.setFocus();
        }
        private void wczytajPilkarza(Piłkarz pilkarz)
        {
            TextBoxWEPImie.tekst = pilkarz.Imie;
            TextBoxWEPNazwisko.tekst = pilkarz.Nazwisko;
            WiekSlider.Value = pilkarz.Wiek;
            WagaSlider.Value = pilkarz.Waga;
            buttonEdytuj.IsEnabled = true;
            buttonUsun.IsEnabled = true;
            TextBoxWEPImie.setFocus();
        }

        private void zamkniecieOkna(object sender, System.ComponentModel.CancelEventArgs e)
        {
            int n = listBoxPilkarze.Items.Count;
            Piłkarz[] pilkarze = null;
            if (n > 0)
            {
                pilkarze = new Piłkarz[n];
                int index = 0;
                foreach (var o in listBoxPilkarze.Items)
                {
                    pilkarze[index++] = o as Piłkarz;
                }
                Archiwizacja.zapisDoPliku(plikArchiwizacji, pilkarze);
            }
        }

        private void otwieranieOkna(object sender, RoutedEventArgs e)
        {
            var pilkarze = Archiwizacja.odczytZPliku(plikArchiwizacji);
            if (pilkarze != null)
                foreach (var p in pilkarze)
                {
                    listBoxPilkarze.Items.Add(p);
                }

        }
    }
}
