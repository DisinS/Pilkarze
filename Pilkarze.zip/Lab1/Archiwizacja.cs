﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Lab1
{
    static class Archiwizacja
    {
        public static void zapisDoPliku(string plik, Piłkarz[] pilkarze)
        {
            using (StreamWriter stream = new StreamWriter(plik))
            {
                foreach (var pilkarz in pilkarze)
                    stream.WriteLine(pilkarz.formatPlikowy());
                stream.Close();
            }
        }

        public static Piłkarz[] odczytZPliku(string plik)
        {
            Piłkarz[] pilkarze = null;
            if (File.Exists(plik))
            {
                var zapisPilkarza = File.ReadAllLines(plik);
                if (zapisPilkarza.Length > 0)
                {
                    pilkarze = new Piłkarz[zapisPilkarza.Length];
                    for (int i = 0; i < zapisPilkarza.Length; i++)                    
                        pilkarze[i] = Piłkarz.CreateFromString(zapisPilkarza[i]);
                }
            }
            return pilkarze;
        }
    }
}
